#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

void printTabInt(int *tab, int length);

void printTabChar(char *tab, int length);
#endif // UTILS_H_INCLUDED

